import java.util.HashMap;

public class Encoder {

    //TThe protected keyword is an access modifier used for attributes,
    // methods and constructors, making them accessible in the same package and subclasses.
    protected String offset;

    protected int offsetValue;

    //This map data is coming from the reference table.
    protected String[] map =
            {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P",
                    "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5",
                    "6", "7", "8", "9", "(", ")", "*", "+", ",", "-", ".", "/"};

    //Create a HashMap object called IndexString that will store String keys and Integer values:
    // from both the String offset(Keys) and int offsetValue (value)
    protected HashMap<String, Integer> IndexString = new HashMap<String, Integer>();
    
    public Encoder(String offset) {
        this.offset = offset;
        for (int i = 0; i < map.length; i++) {
            IndexString.put(map[i], i);
        }
        this.offsetValue = IndexString.get(offset);
    }

    public String encode(String plainText) {
        String result = offset;
        for (int i = 0; i < plainText.length(); i++) {
            String temp = Character.toString(plainText.charAt(i));
            if (IndexString.containsKey(temp)) {
                int index = this.IndexString.get(temp);
                int newIndex = (index - this.offsetValue) % this.map.length;
                if (newIndex < 0) {
                    newIndex += this.map.length;
                }
                result += map[newIndex];
            } else {
                result += temp;
            }
        }
        return result;
    }
}