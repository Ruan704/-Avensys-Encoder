import java.util.HashMap;

public class Decoder extends Encoder{


    public Decoder() {
        super("A");
    }


    public String decode(String encodedText) {
        String offset = Character.toString(encodedText.charAt(0));
        int offsetValue = this.IndexString.get(offset) * -1;
        this.offsetValue = offsetValue;
        String result = super.encode(encodedText);
        result = result.substring(2);
        return result;
    }
}