import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        //creates a new Scanner instance which points to the input stream passed as argument.
        //通过new Scanner(System.in)创建一个Scanner，控制台会一直等待输入，直到敲回车键结束，把所输入的内容传给Scanner，作为扫描对象。
        Scanner scanner = new Scanner(System.in);
        //
        System.out.println("Enter an offset: ");
        String offset = scanner.nextLine();
        System.out.println("Enter a string to be encoded: ");
        String inputString = scanner.nextLine();
        Encoder encoder = new Encoder(offset);
        Decoder decoder = new Decoder();
        String encodedString = encoder.encode(inputString);
        String decodedString = decoder.decode(encodedString);
        System.out.println("The encoded string is: " + encodedString);
        System.out.println("The decoded string is: " + decodedString);
    }

}
